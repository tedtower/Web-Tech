Since the website contains PHP files, the hosting of the website needs to be done using a WAMP server.
the landing page of our website can be found using the url localhost/9352-G8/FINALS/index.html