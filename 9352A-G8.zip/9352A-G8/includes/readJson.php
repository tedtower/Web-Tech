<?php
    $json = file_get_contents("../json/questions.json");
    $array = json_decode($json, true);
?>