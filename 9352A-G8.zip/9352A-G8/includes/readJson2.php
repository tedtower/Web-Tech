<?php
    $json = file_get_contents("../json/questions2.json");
    $array = json_decode($json, true);
?>